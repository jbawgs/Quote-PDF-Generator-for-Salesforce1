({
	loadpdf : function(component, event, helper) {
		helper.loadpdf(component,event);
	}
})